<?php

use simplerest\core\interfaces\IMigration;
use simplerest\core\libs\Factory;
use simplerest\core\libs\Schema;
use simplerest\core\Model;
use simplerest\core\libs\DB;

class TblCiudadConstrainst367 implements IMigration
{
    /**
	* Run migration.
    *
    * @return void
    */
    public function up()
    {
        Model::query("ALTER TABLE tbl_ciudad   ADD COLUMN ica_intIdICA INT(11)  NULL;");
        Model::query("ALTER TABLE tbl_ciudad 
        ADD CONSTRAINT FK_ciudad_retencion_ica FOREIGN KEY (ica_intIdICA)
          REFERENCES tbl_rete_ica(ric_intId);");
    }
}

