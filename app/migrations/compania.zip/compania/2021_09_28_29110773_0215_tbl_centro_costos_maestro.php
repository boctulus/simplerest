<?php

use simplerest\core\interfaces\IMigration;
use simplerest\libs\Factory;
use simplerest\libs\Schema;
use simplerest\core\Model;
use simplerest\libs\DB;

class TblCentroCostosMaestro215 implements IMigration
{
    /**
	* Run migration.
    *
    * @return void
    */
    public function up()
    {
        Model::query("CREATE TABLE tbl_centro_costos (
  cco_intId INT(11) NOT NULL AUTO_INCREMENT,
  cco_varCodigo VARCHAR(20) NOT NULL,
  cco_varCentroCostos VARCHAR(100) NOT NULL,
  cco_dtimFechaCreacion DATETIME NOT NULL DEFAULT current_timestamp(),
  cco_dtimFechaActualizacion DATETIME NULL DEFAULT NULL,
  est_intIdEstado INT(11) NOT NULL DEFAULT 1,
  usu_intIdCreador INT(11) NOT NULL,
  usu_intIdActualizador INT(11) NOT NULL,
  PRIMARY KEY (cco_intId, cco_varCodigo)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_general_ci,
COMMENT = ' * Descripcion: Tabla para registrar los diferentes Centro de Costos.
 * Author: http://www.divergente.net.co';");
    }
}

