<?php

namespace Boctulus\Simplerest\Core\exceptions;

class TableAlreadyExistsException extends \Exception {}