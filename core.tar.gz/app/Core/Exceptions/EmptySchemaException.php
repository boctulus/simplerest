<?php

namespace Boctulus\Simplerest\Core\exceptions;

class EmptySchemaException extends \Exception {}