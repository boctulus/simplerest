<?php

namespace Boctulus\Simplerest\Core\exceptions;

class InvalidValidationException extends \InvalidArgumentException {

}