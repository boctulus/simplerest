<?php

namespace Boctulus\Simplerest\Core\Interfaces;

interface ISchema {
    static function get(); 
}
