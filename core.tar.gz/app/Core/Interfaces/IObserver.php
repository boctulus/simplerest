<?php

namespace Boctulus\Simplerest\core\interfaces;

interface IObserver {
    
}