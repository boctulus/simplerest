<?php

namespace Boctulus\Simplerest\Core\Interfaces;

interface IMyArrayAccess {
    // methods

}