<?php

namespace __NAMESPACE__;

use Boctulus\Simplerest\Core\Libs\DB;
use Boctulus\Simplerest\Core\Request;
use Boctulus\Simplerest\Core\Response;
use Boctulus\Simplerest\Core\Libs\Factory;
use Boctulus\Simplerest\Core\Controllers\ConsoleController;

class __NAME__ extends ConsoleController
{
    function __construct()
    {
        parent::__construct();        
    }
}

