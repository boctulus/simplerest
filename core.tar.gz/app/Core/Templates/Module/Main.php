<?php

namespace __NAMESPACE__;

use Boctulus\Simplerest\Core\Libs\Config;
use Boctulus\Simplerest\Core\Libs\DB;
use Boctulus\Simplerest\Core\Libs\Module;

class __NAME__ extends Module
{
    function __construct(){
        parent::__construct();
    }

    function index()
    {
        // css_file(__DIR__ . '/assets/css/styles.css');
        // js_file('third_party/jquery/3.3.1/jquery.min.js'); 

        // return get_view(__DIR__ . '/views/some-view.php');
    }
}