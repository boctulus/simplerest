<?php 

/*
    Module config's file

    Settings accesible as '{module-name}.key' using Config::get()
*/
return [
    // ...
];