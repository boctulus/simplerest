<?php

namespace __NAMESPACE__;

use Boctulus\Simplerest\pages\Page;

class __NAME__ extends Page
{
    public $tpl_params = [
        'title'      => 'The Page Title',
        'page_name'  => 'The Page Name'
    ];

    function index(){
    }
}