<?php

namespace __NAMESPACE__;

trait __NAME__
{
     
}
