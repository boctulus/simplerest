<?php

// namespace __NAMESPACE__;

interface __NAME__ {
    // __METHODS__
}