<?php

namespace __NAMESPACE__;

use Boctulus\Simplerest\Core\Libs\Strings;

class __NAME__
{
    function __construct() { }


}

