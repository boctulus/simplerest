<?php

namespace __NAMESPACE__;

class __NAME__ {
    // ..
}