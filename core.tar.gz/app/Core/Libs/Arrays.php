<?php declare(strict_types=1);

namespace Boctulus\Simplerest\Core\Libs;

use Boctulus\Simplerest\Core\libs\Strings;

class Arrays 
{
    public static function reorderArray(array $array, array $order_keys): array {
        $orderedArray = [];

        // Insertar las claves en el orden especificado
        foreach ($order_keys as $key) {
            if (array_key_exists($key, $array)) {
                $orderedArray[$key] = $array[$key];
                unset($array[$key]); // Eliminar del original para evitar duplicados
            }
        }

        // Insertar las claves restantes al final
        return array_merge($orderedArray, $array);
    }

    /*
        Trata un array no-asociativo como un Set (conjunto)

        y agrega el valor sino existe en el mismo
    */
    static function pushIfNotExists(array &$array, $value, bool $strict = false){
        $id = array_search($value, $array, $strict);

        if ($id !== false){
            $array[] = $id;
        }
    }

    /*
        Trata un array no-asociativo como un Set (conjunto)

        Si existe el valor en un array no-asociativo,
        lo encuentra y destruye
    */
    static function destroyIfExists(array &$array, $value, bool $strict = false){
        $id = array_search($value, $array, $strict);

        if ($id !== false){
            unset($array[$id]);
        }
    }

    /*
        Para aplicar el filtro al primer nivel del array
    */
    static function filterKeys(array $arr, array $keys) {
        return array_intersect_key($arr, array_flip($keys));
    }
    
    /*
        Para un conjunto de rows

        Por eficiencia se recibe $rows referencia 
    */
    static function filterKeysRows(array &$rows, array $keys){
        foreach ($rows as $ix => $row){
            $rows[$ix] = static::filterKeys($row, $keys);
        }
    }

    /*
        Implementacion alternativa a filterKeysRows()
    */
    static function getColumns(array $rows, array $keys) {
        $filtered = array();

        foreach ($rows as $row) {
            $filteredRow = [];

            foreach ($keys as $key) {
                if (array_key_exists($key, $row)) {
                    $filteredRow[$key] = $row[$key];
                }
            }

            $filtered[] = $filteredRow;
        }

        return $filtered;
    }

    static function stringToArray(string $str, bool $discard_empty_lines = true) : array {
        return Strings::lines($str, true, !$discard_empty_lines);
    }
    
    /*
        Trim every element of array
    */
    static function trimArray(Array $strings){
		return array_map(function($item) {
			// Maneja arrays anidados recursivamente
			if (is_array($item)) {
				return self::trimArray($item);
			}
			// Convierte a string si es necesario
			return trim((string) $item);
		}, $strings);
	}

    static function rtrimArray(array $arr){
        return array_map('rtrim', $arr);
    }

    static function ltrimArray(array $arr){
        return array_map('rtrim', $arr);
    }

    // Sanitiza Keys de array asociativo
	static function sanitizeArrayKeys($data){
		$keys    = array_keys($data);
		$values  = array_values($data);

		foreach ($keys as $ix => $key){
			$keys[$ix] = Strings::sanitize($key);
		}

		return array_combine($keys, $values);
	}
       
    /**
     * Gets the first key of an array
     *
     * @param array $array
     * @return mixed
     */
    static function arrayKeyFirst(array $arr) {
        foreach($arr as $key => $unused) {
            return $key;
        }
        return null;
    }

    static function arrayValueFirst(array $arr) {
        foreach($arr as $val) {
            return $val;
        }
        return null;
    }

    /**
     * shift
     *
     * @param  array  $arr
     * @param  string $key
     * @param  string $default_value
     *
     * @return mixed
     */
    static function shift(&$arr, $key, $default_value = NULL)
    {
        $out = $arr[$key] ?? $default_value;
        unset($arr[$key]);
        return $out;
    }

    static function shiftOrFail(&$arr, $key, string $error_msg)
    {
        if (!isset($arr[$key])){
            throw new \Exception(sprintf($error_msg, [$key]));
        }

        $out = $arr[$key];
        unset($arr[$key]);
        return $out;
    }

    /*
      Renombra las claves de un array según el mapeo proporcionado.
     
      @param array $arr      El array original.
      @param array $mapeoClaves El mapeo de claves a aplicar.
      @return array El array transformado con las claves renombradas.
      
      Ej:
      
        $miArray = [
            [
                'nombre' => 'Pablo',
                'edad' => 99
            ],
            [
                'nombre' => 'Feli',
                'edad' => 12
            ]
        ];

        $mapeoClaves = [
            'nombre' => 'name',
            'edad' => 'age'
        ];

        $arrayTransformado = Arrays::renameKeys($miArray, $mapeoClaves);

        // Resultado:

        Array
        (
            [0] => Array
                (
                    [name] => Pablo
                    [age] => 99
                )

            [1] => Array
                (
                    [name] => Feli
                    [age] => 12
                )

        )
     */
    public static function renameKeys(array $arr, array $mapeoClaves): array {
        $renombrarClaves = function ($clave, $valor) use ($mapeoClaves) {
            return array_key_exists($clave, $mapeoClaves) ? [$mapeoClaves[$clave] => $valor] : [$clave => $valor];
        };

        return array_replace_recursive(...array_map(fn($k, $v) => $renombrarClaves($k, is_array($v) ? self::renameKeys($v, $mapeoClaves) : $v), array_keys($arr), $arr));
    }
    
    // Renombra una key de un Array
    static function renameKey(&$arr, $current_key, $new_key){
        $arr[$new_key] = $arr[$current_key];
        unset($arr[$current_key]);
    }


    static function toJSON($arr){
        $data = json_encode($arr, JSON_UNESCAPED_SLASHES);
        return  str_replace("\r\n", '', $data);
    }

    /**
     * nonAssoc
     * Turns associative into non associative array
     * 
     * @param  array $arr
     *
     * @return array
     */
    static function nonAssoc(array $arr){
        $out = [];
        foreach ($arr as $key => $val) {
            $out[] = [$key, $val];
        }
        return $out;
    }
 
    /*
        Solo se es no-asociativo si ninguna key es no-numerica

        Deberia chequear cual opcion es realmente mas rapida
    */
    static function isNonAssoc(array $arr, $fast_way = false)
    {
        if ($fast_way){
            $keys = array_keys($arr);

            foreach($keys as $key){
                if (!is_int($key)){
                    return false;
                }
            }		

            return true;
        } else {
            return array_keys($arr) === range(0, count($arr) - 1);
        }
    }

    /*
        Un array es asociativo con que al menos una key sea un string
    */
    static function isAssoc(array $arr, $fast_way = false){
        return !static::isNonAssoc($arr, $fast_way);
    }

    /**
     * Converts recursivly all numeric keys in an array to associative keys, ensuring that each node and leaf of the array is associative.
     * If a numeric key is found and the associated value is not an array, it will convert the key to the value and set an empty array as its value.
     * The function processes the array recursively, so nested arrays will also be transformed.
     *
     * @param array $arr The input array to be transformed.
     * 
     * @return array The modified array where all numeric keys are replaced by associative keys if necessary.
     */
    static function toAssoc($arr) {
        foreach ($arr as $ix => $value) {
            if (is_int($ix) && !is_array($value)) {
                $arr[$value] = [];
                unset($arr[$ix]);
            } elseif (is_array($value)) {
                // Ricorsivamente convertiamo i sotto-array
                $arr[$ix] = static::toAssoc($value);
            }
        }
        return $arr;
    }

    /**
     * A strReplace for PHP
     *
     * As described in http://php.net/str_replace this wouldnot make sense
     * However there are chances that we need it, so often !
     * See https://wiki.php.net/rfc/cyclic-replace
     *
     * @author Jitendra Adhikari | adhocore <jiten.adhikary@gmail.com>
     *
     * @param string $search  The search string
     * @param array  $replace The array to replace $search in cyclic order
     * @param string $subject The subject on which to search and replace
     *
     * @return string
     */
    static function strReplace($search, array $replace, $subject)
    {
        if (empty($subject)){
            return '';
        }

        if (0 === $tokenc = substr_count($subject, $search)) {
            return $subject;
        }
        $string  = '';
        if (count($replace) >= $tokenc) {
            $replace = array_slice($replace, 0, $tokenc);
            $tokenc += 1; 
        } else {
            $tokenc = count($replace) + 1;
        }
        foreach(explode($search, $subject, $tokenc) as $part) {
            $string .= $part.array_shift($replace);
        }
        return $string;
    }

    static function shuffleAssoc($my_array)
	{
        $keys = array_keys($my_array);

        shuffle($keys);

        $new = [];
        foreach($keys as $key) {
            $new[$key] = $my_array[$key];
        }

        return $new;
    }

    /*
        https://stackoverflow.com/a/145348/980631
    */
    static function isMultidim($a) {
        foreach ($a as $v) {
            if (is_array($v)) return true;
        }
        return false;
    }

    /*
         $a = [
            ['a', 'c'],
            ['x' => 7], // <--- false
            ['a', 'c', 5],
        ];
        
        dd(
            Arrays::areSimpleAllSubArrays($a)
        );
    */
    static function areSimpleAllSubArrays($a, $throw_exception = false){
        foreach ($a as $k => $sub){
            if (!is_int($k)){
                return false;
            }

            if (!is_array($sub)){
                if ($throw_exception){
                    throw new \InvalidArgumentException("An element -'$sub'- is not a sub-array as expected");
                }

                return false;
            }

            if (static::isAssoc($sub)){
                return false;
            }
        }

        return true;
    }

    /*
        Dados dos arrays (no-asociativos) $a y $b, se altera el orden en que aparecen los elementos del primer array ($a)
        de forma que sigan el orden impuesto por el array segundo ($b)

        $a sigue el orden impuesto por $a

        Estrictamete hay varias soluciones posibles, todas validas.
    */
    static function followOrder(array $a, array $b) {
        if (count($b) == 0){
            return;
        }

        $first_pos_b_in_a = array_search($b[0], $a);

        list($a1, $a2) = array_chunk($a, $first_pos_b_in_a);

        $a1 = array_diff($a1, $b);
        $a2 = array_diff($a2, $b);

        $a = array_merge($a1, $b, $a2);
        
        return $a;
    }

    // seria mejor en ciertos casos con generadores
    static function chunk($data, $length = null, $offset = 0) {
        if ($offset > 0) {
            $data = array_slice($data, $offset);
        }

        if ($length === null) {
            return $data;
        }

        return array_slice($data, 0, $length);
    }

    /*
        Get property with dot-notation

        Ej:

        $weight_0 = Arrays::get($product_data, 'variations.0.weight');
    */
    static function get(array $data, $property = null, $default = null)
    {        
        if (!static::isAssoc($data)){
            throw new \InvalidArgumentException("Expected associative array. Got " . gettype($data));
        }

        // Split the property into an array of keys
        $keys = explode('.', $property);

        // Traverse the nested array to get the final value
        foreach ($keys as $key) {
            if (isset($data[$key])) {
                $data = $data[$key];
            } else {
                return null; // Property not found
            }
        }

        return $data ?? $default;
    }
    
    /*
        Dado un contenido (entero, string, array,...) y un "path", deja el contenido dentro del path 
        en el array en construccion o sea anidado dentro las keys del path

        Ej:

        $path   = 'data.products';
        $result = Arrays::makeArray($array, $path);
    */
    static function makeArray($content, string $path) {
        $rows_path_s = explode('.', $path);
        $result      = [];
        $current     = &$result;
        
        foreach ($rows_path_s as $key) {
            $current[$key] = [];
            $current = &$current[$key];
        }
        
        $current = $content;
        
        return $result;
    }
    
}

