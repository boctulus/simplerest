<?php declare(strict_types=1);

namespace Boctulus\Simplerest\Core\Libs;

use Boctulus\Simplerest\Core\Traits\ExceptionHandler;

class TemporaryExceptionHandler
{
    use ExceptionHandler;
}

