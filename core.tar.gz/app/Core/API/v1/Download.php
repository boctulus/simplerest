<?php

namespace Boctulus\Simplerest\Core\API\v1;

use Boctulus\Simplerest\Core\Acl;
use Boctulus\Simplerest\Core\API\v1\ResourceController;
use Boctulus\Simplerest\Core\Libs\Factory;
use Boctulus\Simplerest\Core\Libs\DB;


class Download extends ResourceController
{
    // caso puntual donde lo conservo:
    static protected $guest_access = true;

    protected $table_name = 'files';
    protected $tenantid;
    protected $conn;

    function __construct()
    {
        global $api_version;
        $api_version = 'v1';

        parent::__construct();   
        
        $this->tenantid = Factory::request()->getTenantId();

        if ($this->tenantid !== null){
            $this->conn = DB::getConnection($this->tenantid);
        }
    }

    function get($id = null) {
        if (!in_array($_SERVER['REQUEST_METHOD'], ['GET','OPTIONS']))
            error('Incorrect verb ('.$_SERVER['REQUEST_METHOD'].'), expecting GET',405);

        if ($id == null)
            return;

        $_get = [];    
        
        if (!Factory::acl()->hasSpecialPermission('read_all')){
            if (auth()->isGuest()){                
                $instance = DB::table($this->table_name);
                
                if ($instance->inSchema(['guest_access'])){
                    $_get[] = ['guest_access', 1];
                }
                                         
            } else {
                $_get[] = ['belongs_to', auth()->uid()];
            }
        }

        $_get[] = ['uuid', $id];   

        $row = DB::table($this->table_name)->select(['filename_as_stored'])->where($_get)->first();

        if (empty($row))
            error('File not found', 404);
      
        $file = UPLOADS_PATH . $row['filename_as_stored'];

        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.basename($file).'"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            readfile($file);
            exit;
        } else {
            error('File not found', 404, "$file not found in storage");
        }
    }

    function index($id){
        return $this->get($id);
    }
}