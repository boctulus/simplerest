<?php

namespace Boctulus\Simplerest\Core\Traits;

use Boctulus\Simplerest\Core\Exceptions\SchemaException;
use Boctulus\Simplerest\Core\Exceptions\SqlException;
use Boctulus\Simplerest\Core\Libs\DB;

trait RelationshipTrait 
{   
  // mover funciones de db.php aca    
}