<?php

// namespace Boctulus\FriendlyposWeb;

interface Friendlypos_web {
    // __METHODS__
}