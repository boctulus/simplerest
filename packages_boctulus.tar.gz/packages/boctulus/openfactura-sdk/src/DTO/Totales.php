<?php

namespace Boctulus\OpenfacturaSdk\DTO;

class Totales {
    public float $MntNeto;
    public float $TasaIVA;
    public float $IVA;
    public float $MntTotal;
    public float $MontoPeriodo;
    public float $VlrPagar;
}