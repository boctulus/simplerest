<?php

namespace Boctulus\OpenfacturaSdk\DTO;

class Detalle {
    public int $NroLinDet;
    public string $NmbItem;
    public int $QtyItem;
    public float $PrcItem;
    public float $MontoItem;
}