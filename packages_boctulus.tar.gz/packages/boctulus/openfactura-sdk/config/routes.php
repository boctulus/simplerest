<?php

use Boctulus\Simplerest\Core\WebRouter;

/*
    openfactura-sdk Package Web Routes
*/

// Example route:
// WebRouter::get('openfactura-sdk/example', 'Boctulus\OpenfacturaSdk\Controllers\ExampleController@index');
