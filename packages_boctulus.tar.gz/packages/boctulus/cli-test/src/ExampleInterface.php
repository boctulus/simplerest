<?php

namespace Boctulus\CliTest;

interface ExampleInterface {
    // __METHODS__
}