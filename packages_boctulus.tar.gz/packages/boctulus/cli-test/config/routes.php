<?php

use Boctulus\Simplerest\Core\WebRouter;

/*
    cli-test Package Web Routes
*/

// Example route:
// WebRouter::get('cli-test/example', 'Boctulus\CliTest\Controllers\ExampleController@index');
