<?php

namespace Boctulus\FineGrainedACL;

use Boctulus\Simplerest\Core\ServiceProvider;

class FineGrainedAclServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //dd("booting from Boctulus\Simplerest\FineGrainedACL");
        //include __DIR__.'/routes.php';
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
       
    }    
}
