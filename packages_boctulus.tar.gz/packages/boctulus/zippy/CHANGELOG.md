# CHANGE LOG

## Reorganización de Comandos

Ahora se siguen 3 namespaces claros:

product - Procesamiento de productos
category - Gestión de categorías
ollama - Testing de LLM


## Comandos Renombrados:

products_process_categories → product process
test_mapping → category test
category_list → category list_raw
process_categories → product batch
clear_cache → category clear_cache