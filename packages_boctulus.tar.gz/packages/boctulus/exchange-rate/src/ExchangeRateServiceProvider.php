<?php

namespace Boctulus\ExchangeRate;

use Boctulus\Simplerest\Core\ServiceProvider;

class ExchangeRateServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        // dd("Initing service");
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        // dd("Registering " . __CLASS__);
    }    
}
