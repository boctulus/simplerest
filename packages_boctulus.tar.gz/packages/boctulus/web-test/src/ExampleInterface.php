<?php

namespace Boctulus\WebTest;

interface ExampleInterface {
    // __METHODS__
}