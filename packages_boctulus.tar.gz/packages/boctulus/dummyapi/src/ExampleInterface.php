<?php

// namespace Boctulus\Dummyapi;

interface DummyApi {
    // __METHODS__
}