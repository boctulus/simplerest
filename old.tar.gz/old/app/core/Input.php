<?php

namespace simplerest\core;

class Input
{
    function get(){
        
    }

}