# Quickstart — SimpleRest (5 minutos)

## 1) Instalación local (usar repo en disco)
Si aún no publicaste en Packagist, puedes instalar desde ruta local:

```bash
# desde el proyecto consuming
composer config repositories.simplerest path "/ruta/a/simplerest"
composer require boctulus/simplerest:dev-main


<<< COMPLETAR