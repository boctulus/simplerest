<?php

namespace __NAMESPACE;

interface __NAME__ {
    // methods

}