<?php

namespace __NAMESPACE;

use simplerest\core\Model;
use simplerest\core\libs\DB;
use simplerest\core\libs\Factory;

class __NAME__
{
    function __construct() { }


}

