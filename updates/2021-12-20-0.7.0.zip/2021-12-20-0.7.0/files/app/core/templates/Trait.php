<?php

namespace __NAMESPACE;

trait __NAME__
{
     
}
