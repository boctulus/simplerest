<?php

namespace simplerest\libs;

class Msg
{
    # __CONSTANTS 

}

