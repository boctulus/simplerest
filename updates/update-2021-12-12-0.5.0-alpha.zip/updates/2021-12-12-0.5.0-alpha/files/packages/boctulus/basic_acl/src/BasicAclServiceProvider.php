<?php

namespace boctulus\basic_acl;

use simplerest\core\ServiceProvider;

class BasicAclServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //dd("booting from boctulus\basic_acl");
        //include __DIR__.'/routes.php';
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
       
    }    
}
