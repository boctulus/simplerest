<?php

namespace boctulus\grained_acl;

use simplerest\core\ServiceProvider;

class GrainedAclServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //dd("booting from boctulus\grained_acl");
        //include __DIR__.'/routes.php';
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
       
    }    
}
