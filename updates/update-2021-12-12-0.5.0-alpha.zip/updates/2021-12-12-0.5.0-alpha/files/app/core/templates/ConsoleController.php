<?php

namespace __NAMESPACE;

use simplerest\core\ConsoleController;
use simplerest\core\Request;
use simplerest\core\Response;
use simplerest\libs\Factory;
use simplerest\libs\DB;

class __NAME__ extends ConsoleController
{
    function __construct()
    {
        parent::__construct();        
    }
}

