<?php

namespace __NAMESPACE;

use simplerest\controllers\MyController;
use simplerest\core\Request;
use simplerest\core\Response;
use simplerest\libs\Factory;
use simplerest\libs\DB;

class __NAME__ extends MyController
{
    function __construct()
    {
        parent::__construct();        
    }

    function index()
    {
                       
    }
}

