<?php

namespace __NAMESPACE;

use simplerest\core\Model;
use simplerest\libs\DB;
use simplerest\libs\Factory;

class __NAME__
{
    function __construct() { }


}

