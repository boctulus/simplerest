<?php

namespace simplerest\core\exceptions;

class SqlException extends \Exception {

}