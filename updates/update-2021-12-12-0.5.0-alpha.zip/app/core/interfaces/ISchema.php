<?php

namespace simplerest\core\interfaces;

interface ISchema {
    static function get(); 
}
