<?php

namespace simplerest\core\exceptions;

class InvalidValidationException extends \InvalidArgumentException {

}