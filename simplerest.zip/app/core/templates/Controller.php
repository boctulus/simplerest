<?php

namespace __NAMESPACE;

use simplerest\core\Controller;
use simplerest\core\Request;
use simplerest\core\Response;
use simplerest\libs\Factory;
use simplerest\libs\DB;

class __NAME__ extends Controller
{
    function __construct()
    {
        parent::__construct();        
    }
}

