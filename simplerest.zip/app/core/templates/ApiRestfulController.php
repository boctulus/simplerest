<?php

namespace simplerest\controllers\api;

use simplerest\controllers\MyApiController; 

class __NAME__ extends MyApiController
{ 
    static protected $soft_delete = __SOFT_DELETE__;

    function __construct()
    {       
        parent::__construct();
    }        
} 
