<?php

namespace simplerest\controllers;

use simplerest\core\ConsoleController;
use simplerest\core\Request;
use simplerest\core\Response;
use simplerest\libs\Factory;
use simplerest\libs\DB;

class TestController extends ConsoleController
{
    function __construct()
    {
        parent::__construct();        
    }

    function test1(){
        $email = \simplerest\models\TblUsuarioEmpresaModel::$email;
        echo $email;
    }

    function index(){
        dd(get_name_id('tbl_usuario_empresa'));
        dd(get_name_id('products', 'test'));
    }
}

